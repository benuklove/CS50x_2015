<form action="refill.php" method="post">
    <fieldset>
        Enter the amount to add in whole dollars:
        <div class="form-group">
            <input autofocus class="form-control" name="amount" placeholder="Amount" type="text"/>
        </div>
        <div class="form-group">
            <button type="submit" class="btn btn-default">Add Funds</button>
        </div>
    </fieldset>
</form>
<div>
    or back to <a href="index.php">portfolio</a>
</div>
