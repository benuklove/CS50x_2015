/**
 * greedy.c
 * 
 * Ben Love
 * benuklove@gmail.com
 * 
 * Returns change
 */

#include <cs50.h>
#include <stdio.h>
#include <math.h>

int main(void)
{

// asks user the amount of change owed and validates positive float
    float change;
    do
    {
        printf("How much change is owed?\n");
        change = GetFloat();
        printf("%f\n", change);
    }
    while (change < 0);
    
    // Rounding the change here.  Correctly?  Who knows?
    double pennies;
    pennies = round(change * 100);
    printf("Your change is %.50f pennies.\n", pennies);
    
    // cast double as int
    int cents = pennies;
    printf("or %d cents\n", cents);
    
    // experiment with floating point value
    float f = .41;
    printf("%.50f\n", f);
    
    // now for the change part - maybe use modulo with division?
    int q = cents / 25 - ((cents % 25) / 25);
    printf("Quarters: %d\n", q);
    int d = (cents - q * 25) / 10 - (((cents - q * 25) % 10) / 10);
    printf("Dimes: %d\n", d);
    int n = (cents - q * 25 - d * 10) / 5 - (((cents - q * 25 - d * 10) % 5) / 5);
    printf("Nickels: %d\n", n);    
    int p = (cents - q * 25 - d * 10 - n * 5);
    printf("Pennies: %d\n", p);    
    int total = q + d + n + p;
    printf("The minimum number of coins returned is %d\n", total);
        
}

